#!/bin/bash

clear

source functions.bash
source vars.bash

freshstart

shuffle

deal

render

mull

render

sleep 1
