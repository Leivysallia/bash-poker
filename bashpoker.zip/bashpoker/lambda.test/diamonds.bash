acediamonds="┌┈┈┈┐
|♦--|
|-A-|
|--♦|
└┈┈┈┘"

twodiamonds="┌┈┈┈┐
|♦--|
|-2-|
|--♦|
└┈┈┈┘"

threediamonds="┌┈┈┈┐
|♦--|
|-3-|
|--♦|
└┈┈┈┘"

fourdiamonds="┌┈┈┈┐
|♦--|
|-4-|
|--♦|
└┈┈┈┘"

fivediamonds="┌┈┈┈┐
|♦--|
|-5-|
|--♦|
└┈┈┈┘"

sixdiamonds="┌┈┈┈┐
|♦--|
|-6-|
|--♦|
└┈┈┈┘"

sevendiamonds="┌┈┈┈┐
|♦--|
|-7-|
|--♦|
└┈┈┈┘"

eightdiamonds="┌┈┈┈┐
|♦--|
|-8-|
|--♦|
└┈┈┈┘"

ninediamonds="┌┈┈┈┐
|♦--|
|-9-|
|--♦|
└┈┈┈┘"

tendiamonds="┌┈┈┈┐
|♦--|
|-X-|
|--♦|
└┈┈┈┘"

jackdiamonds="┌┈┈┈┐
|♦--|
|-J-|
|--♦|
└┈┈┈┘"

queendiamonds="┌┈┈┈┐
|♦--|
|-Q-|
|--♦|
└┈┈┈┘"

kingdiamonds="┌┈┈┈┐
|♦--|
|-K-|
|--♦|
└┈┈┈┘"